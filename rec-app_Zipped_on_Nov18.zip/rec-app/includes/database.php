<?php


$dsn = "mysql:host=localhost;alexbeli_app";

$db_username = "alexbeli_usr3";
$db_password = "Alfan9x77xMrk";

$pdo = new PDO($dsn, $db_username, $db_password);



?>