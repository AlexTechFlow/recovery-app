<?php ?>
<footer><p>&copy; Alex & Evelyn</p></footer>	
</div>
</body>
</html>